from board import LED
import time 

led_red = LED(1)

while (True):
   
    # Turn on LEDs
    led_red.on()

    # Wait 0.25 seconds
    time.sleep_ms(250)
    
    # Turn off LEDs
    led_red.off()

    # Wait 0.25 seconds
    time.sleep_ms(250)